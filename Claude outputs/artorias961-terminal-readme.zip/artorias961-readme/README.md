<div align="center">

<img src="assets/hero.svg" width="100%" alt="Terminal: whoami — Christopher Morales. I’m an engineer who enjoys building real things at the intersection of hardware and software. Many of my projects are inspired by video games, taking ideas from virtual worlds and turning them into physical systems. I learn by building, breaking, and refining, driven mostly by curiosity and a simple “why not?”.">

<a href="https://artorias961.netlify.app"><img src="https://img.shields.io/badge/website-1a1b26?style=for-the-badge&logo=netlify&logoColor=73daca" alt="Website"></a>
<a href="https://christopher-morales.vercel.app"><img src="https://img.shields.io/badge/portfolio-1a1b26?style=for-the-badge&logo=vercel&logoColor=bb9af7" alt="Portfolio"></a>
<a href="https://github.com/artorias961"><img src="https://img.shields.io/badge/github-1a1b26?style=for-the-badge&logo=github&logoColor=c0caf5" alt="GitHub"></a>
<a href="https://www.linkedin.com/in/artorias961/"><img src="https://img.shields.io/badge/linkedin-1a1b26?style=for-the-badge&logo=linkedin&logoColor=7aa2f7" alt="LinkedIn"></a>

</div>

<br>

<img src="assets/onefetch.svg" width="100%" alt="onefetch-style card. Project: hardware + software, one build at a time. Pending (learning): C/C++, Zephyr RTOS, ROS, practical Linux. Topics: Embedded Systems, BLE, Wireless, Robotics. Languages: Python, C, C++, Bash. Builds: embedded + firmware experiments, BLE tooling / device comms, robotics + sensors, DIY keyboards and electronics. Ask me about: Python, embedded dev, BLE, Linux workflows. Fun fact: late-night walks + music hit different. Portfolio: christopher-morales.vercel.app">

<br><br>

<img src="assets/neofetch.svg" width="100%" alt="neofetch-style workstation specs. OS: Linux (daily driver). Case: Fractal North Charcoal Black. Board: ProArt Z890-CREATOR WIFI. CPU: Intel Core Ultra 7 265K. GPU: GIGABYTE GeForce RTX 5080. Memory: 64GB DDR5. Disks: 1TB WD Blue SN580 NVMe, 1TB Samsung SSD 860 EVO. PSU: Corsair RM1000x. Cooler: Noctua NH-D15. Tools: bash, git, docker, MATLAB, Raspberry Pi, Arduino, React, Redis.">

<details>
<summary><code>$ xdg-open ~/pictures/workstation.gif</code></summary>
<br>
<img src="https://github.com/user-attachments/assets/748982fe-7df8-4c48-9859-928e030f7fcf" width="100%" alt="My workstation">
</details>

<br>

<img src="assets/stack.svg" width="100%" alt="tree ~/stack — embedded: C, C++, Arduino (firmware, protocols, device bring-up). scripting: Python, Bash (automation, testing, data parsing). systems: Linux, Docker, Git (workflows, containers, version control). hw-diy: Raspberry Pi (prototyping, tooling, side builds).">

<br>

<img src="assets/stats.svg" width="100%" alt="Terminal: ./github-stats --user artorias961 --theme tokyonight">

<p align="center">
  <img src="https://github-readme-stats-fast.vercel.app/api?username=artorias961&show_icons=true&theme=tokyonight" alt="GitHub stats">
  <img src="https://github-readme-stats-fast.vercel.app/api/streak?username=artorias961&theme=tokyonight&hide_border=false" alt="GitHub streak">
  <img src="https://github-readme-stats-fast.vercel.app/api/top-langs/?username=artorias961&theme=tokyonight&hide_border=false&include_all_commits=false&count_private=true&layout=compact" alt="Top languages">
</p>

<img src="assets/exit.svg" width="100%" alt="Terminal: exit — logout. Connection to artorias961 closed. Thanks for stopping by — see you in the next build.">

<!--
  The terminal cards in assets/ are generated. To change any text:
    pip install fonttools brotli
    python3 scripts/build_cards.py
-->
